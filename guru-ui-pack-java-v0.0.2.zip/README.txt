GURU UI Tiles - Java 1.21.10+ (NUMERIC)

This pack uses assets/minecraft/items/paper.json with minecraft:select on minecraft:custom_model_data.
It matches the plugin's legacy meta.setCustomModelData(int) mapping.

Test:
/give @p minecraft:paper[minecraft:custom_model_data={value:1000}]
/give @p minecraft:paper[minecraft:custom_model_data={value:1100}]
/give @p minecraft:paper[minecraft:custom_model_data={value:1300}]
