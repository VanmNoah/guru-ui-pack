GURU GUI Tiles Resource Pack (Java) - PRO

Target: Minecraft Java 1.21.10 (pack_format 69)
Carrier item: minecraft:paper

CustomModelData mapping (GuiAssetKey -> cmd -> model):
- BACKGROUND: 1000 -> guru_gui:item/ui/background
- PANEL: 1001 -> guru_gui:item/ui/panel
- HEADER_BAR: 1010 -> guru_gui:item/ui/header_bar
- FOOTER_BAR: 1011 -> guru_gui:item/ui/footer_bar
- SPACER: 1012 -> guru_gui:item/ui/spacer
- BUTTON_PRIMARY: 1100 -> guru_gui:item/ui/button_primary
- BUTTON_SECONDARY: 1101 -> guru_gui:item/ui/button_secondary
- BUTTON_DANGER: 1102 -> guru_gui:item/ui/button_danger
- BACK: 1200 -> guru_gui:item/ui/back
- CLOSE: 1201 -> guru_gui:item/ui/close
- NEXT: 1202 -> guru_gui:item/ui/next
- PREV: 1203 -> guru_gui:item/ui/prev
- ICON_DOMAINS: 1300 -> guru_gui:item/ui/icon_domains
- ICON_MARKET: 1301 -> guru_gui:item/ui/icon_market
- ICON_TRANSPORT: 1302 -> guru_gui:item/ui/icon_transport
- ICON_PROFILE: 1303 -> guru_gui:item/ui/icon_profile
- LOADING_SPINNER: 1400 -> guru_gui:item/ui/loading_spinner
- PLACEHOLDER: 1500 -> guru_gui:item/ui/placeholder