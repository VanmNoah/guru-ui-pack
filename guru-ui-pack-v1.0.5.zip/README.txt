GURU UI Tiles - Java 1.21.10+

This pack uses the new 1.21.4+ item definition system:
- assets/minecraft/items/paper.json (minecraft:select with minecraft:custom_model_data)

Test commands:
/give @p minecraft:paper[minecraft:custom_model_data={strings:["background"]}]
/give @p minecraft:paper[minecraft:custom_model_data={strings:["button_primary"]}]
/give @p minecraft:paper[minecraft:custom_model_data={strings:["icon_domains"]}]
