GURU GUI Tiles Resource Pack (Java) - Placeholder

Target: Minecraft Java 1.21.10 (pack_format 69)

This pack provides placeholder textures/models for the CustomModelData IDs used by guru-gui's gui-theme.yml.

Namespace: guru_gui

Items overridden:
- minecraft:paper
- minecraft:gray_stained_glass_pane
- minecraft:light_gray_stained_glass_pane
- minecraft:black_stained_glass_pane

Mapping (GuiAssetKey -> item -> CustomModelData -> model):
- BACKGROUND -> minecraft:gray_stained_glass_pane -> 1000 -> guru_gui:item/ui/background
- PANEL -> minecraft:light_gray_stained_glass_pane -> 1010 -> guru_gui:item/ui/panel
- HEADER_BAR -> minecraft:black_stained_glass_pane -> 1020 -> guru_gui:item/ui/header_bar
- FOOTER_BAR -> minecraft:black_stained_glass_pane -> 1030 -> guru_gui:item/ui/footer_bar
- SPACER -> minecraft:black_stained_glass_pane -> 1040 -> guru_gui:item/ui/spacer
- BUTTON_PRIMARY -> minecraft:paper -> 2000 -> guru_gui:item/ui/button_primary
- BUTTON_SECONDARY -> minecraft:paper -> 2010 -> guru_gui:item/ui/button_secondary
- BUTTON_DANGER -> minecraft:paper -> 2020 -> guru_gui:item/ui/button_danger
- CLOSE -> minecraft:paper -> 3000 -> guru_gui:item/ui/close
- BACK -> minecraft:paper -> 3010 -> guru_gui:item/ui/back
- NEXT -> minecraft:paper -> 3020 -> guru_gui:item/ui/next
- PREV -> minecraft:paper -> 3030 -> guru_gui:item/ui/prev
- LOADING_SPINNER -> minecraft:paper -> 4000 -> guru_gui:item/ui/loading_spinner
- ICON -> minecraft:paper -> 5000 -> guru_gui:item/ui/icon
- ICON_DOMAINS -> minecraft:paper -> 5100 -> guru_gui:item/ui/icon_domains
- ICON_MARKET -> minecraft:paper -> 5110 -> guru_gui:item/ui/icon_market
- ICON_TRANSPORT -> minecraft:paper -> 5120 -> guru_gui:item/ui/icon_transport
- ICON_PROFILE -> minecraft:paper -> 5130 -> guru_gui:item/ui/icon_profile
- PLACEHOLDER -> minecraft:paper -> 9000 -> guru_gui:item/ui/placeholder
